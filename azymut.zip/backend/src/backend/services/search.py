from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import httpx
from tortoise.expressions import Q

from backend.api.schemas.search import (
    SEARCH_REASONS_JSON_SCHEMA,
    SearchFilter,
    SearchRequest,
    SearchResponse,
    SearchResult,
    SearchResultFlag,
    SettingPreference,
)
from backend.api.schemas.weather import (
    WeatherCondition,
    WeatherForecast,
    WeatherProviderError,
)
from backend.db.models import Event, OpeningHours, Place, PriceLevel
from backend.llm.client import LLMClient, LLMUnavailableError
from backend.llm.parser import extract_json_object
from backend.llm.query_parser import (
    ParsedQuery,
    explicit_search_filter_for_summary,
    parse_search_query,
    query_event_intent,
    query_excerpt,
)
from backend.services.search_events import (
    event_name_boost,
    filter_events_for_query,
    venue_place_penalty,
)
from backend.services.search_preferences import (
    merge_user_preferences,
    preferences_query_suffix,
    resolve_interest_layers,
)
from backend.services.search_rank import ScoreInput, WeatherBias, rank_matches
from backend.services.search_venue_mention import (
    mention_scores_for_catalog,
    strong_mention_keys,
)
from backend.services.weather import get_weather_service
from backend.settings import Settings, get_settings

_WARSAW = ZoneInfo("Europe/Warsaw")
_PLOCK_LAT = 52.5468
_PLOCK_LON = 19.7064
_MIN_STOPS_WITHOUT_EXPLICIT_PLAN = 2
_VENUE_FOCUS_RESULT_CAP = 3
_WEEKDAYS_PL = (
    "poniedziałek",
    "wtorek",
    "środa",
    "czwartek",
    "piątek",
    "sobota",
    "niedziela",
)
_BAD_WEATHER = {WeatherCondition.RAIN, WeatherCondition.SNOW, WeatherCondition.STORM}
_REASONS_PROMPT = (
    Path(__file__).resolve().parents[1] / "llm" / "prompts" / "search_reasons.pl.md"
)


def warsaw_today() -> date:
    return datetime.now(_WARSAW).date()


def summarize_filter(filt: SearchFilter) -> str:
    parts: list[str] = []
    if filt.time_budget_minutes:
        minutes = filt.time_budget_minutes
        if minutes % 60 == 0:
            hours = minutes // 60
            if hours == 1:
                parts.append("1 godzina")
            elif hours < 5:
                parts.append(f"{hours} godziny")
            else:
                parts.append(f"{hours} godzin")
        else:
            parts.append(f"{minutes} min")
    if filt.day_of_week is not None:
        parts.append(_WEEKDAYS_PL[filt.day_of_week])
    if filt.group.children:
        noun = "dziecko" if filt.group.children == 1 else "dzieci"
        parts.append(f"{filt.group.children} {noun}")
    if filt.max_price_level == 0 and filt.price_strict:
        parts.append("bezpłatne")
    elif filt.max_price_level == 0:
        parts.append("najlepiej bezpłatne")
    elif filt.max_price_level == 1 and not filt.price_strict:
        parts.append("tanio")
    if filt.setting is SettingPreference.OUTDOOR:
        parts.append(
            "tylko na zewnątrz" if filt.setting_strict else "na świeżym powietrzu"
        )
    elif filt.setting is SettingPreference.INDOOR:
        parts.append("tylko pod dachem" if filt.setting_strict else "pod dachem")
    if filt.city:
        parts.append(filt.city)
    return " · ".join(parts) if parts else "Propozycje na Twój czas"


def summarize_search_response(
    query: str,
    filt: SearchFilter,
    results: list[SearchResult],
    *,
    venue_focus: bool,
    today: date,
) -> str:
    """Nagłówek planu: venue → nazwy; inaczej skrót zapytania + chipy tylko z tekstu."""
    if venue_focus and results:
        return " · ".join(item.name for item in results[:_VENUE_FOCUS_RESULT_CAP])

    stripped = query.strip()
    excerpt = query_excerpt(stripped)
    chips = summarize_filter(
        explicit_search_filter_for_summary(stripped, today=today),
    )
    if chips == "Propozycje na Twój czas":
        chips = ""
    parts = [part for part in (excerpt, chips) if part]
    return " · ".join(parts) if parts else "Propozycje na Twój czas"


def _weather_note(bias: WeatherBias, setting: SettingPreference) -> str | None:
    if not bias.used:
        return None
    if bias.raining:
        return (
            "Prognoza zapowiada deszcz — wyżej są miejsca pod dachem "
            "i te, które dobrze znoszą deszcz."
        )
    if setting is SettingPreference.OUTDOOR:
        return "Pogoda sprzyja wyjściu na świeże powietrze."
    return "Pogoda nie powinna przeszkadzać w planie."


def _split_secondary(value: str | None) -> tuple[str, ...]:
    if not value:
        return ()
    return tuple(part.strip() for part in value.split(";") if part.strip())


def _price_int(value: PriceLevel | int | None) -> int | None:
    if value is None:
        return None
    return int(value)


def _minutes_between(start: str | None, end: str | None) -> int | None:
    if not start or not end or ":" not in start or ":" not in end:
        return None
    try:
        start_h, start_m = (int(part) for part in start.split(":", 1))
        end_h, end_m = (int(part) for part in end.split(":", 1))
    except ValueError:
        return None
    delta = (end_h * 60 + end_m) - (start_h * 60 + start_m)
    if delta <= 0:
        return None
    return delta


def _kids(filt: SearchFilter) -> bool:
    return filt.group.children > 0 or bool(filt.group.child_ages)


def _place_visit_minutes(place: Place) -> int:
    if place.typical_visit_minutes is not None and place.typical_visit_minutes > 0:
        return place.typical_visit_minutes
    return 30


def _event_visit_minutes(event: Event) -> int:
    duration = _minutes_between(event.start_time, event.end_time)
    if duration is not None and duration > 0:
        return duration
    return 120


def _apply_query_relevance(
    ranked: list[tuple[ScoreInput, float]],
    *,
    query: str,
    mention_scores: dict[str, float],
    place_by_key: dict[str, Place],
    event_by_key: dict[str, Event],
    event_intent: bool,
) -> list[tuple[ScoreInput, float]]:
    boosted: list[tuple[ScoreInput, float]] = []
    for item, score in ranked:
        total = score + mention_scores.get(item.key, 0.0)
        if item.kind == "event":
            event = event_by_key[item.key]
            total += event_name_boost(event.name, query)
        elif event_intent:
            place = place_by_key[item.key]
            total -= venue_place_penalty(place.name, event_intent=True)
        boosted.append((item, total))
    boosted.sort(key=lambda pair: (-pair[1], pair[0].key))
    return boosted


def _pack_ranked_within_budget(
    ranked: list[tuple[ScoreInput, float]],
    *,
    place_by_key: dict[str, Place],
    event_by_key: dict[str, Event],
    budget_minutes: int | None,
    limit: int,
    stop_count: int | None = None,
    places_only: bool = False,
    min_stops: int | None = None,
    pin_keys: set[str] | None = None,
) -> list[tuple[ScoreInput, float]]:
    """Budżet czasu jest sumą czasu zwiedzania / wydarzeń, nie limitem na jeden punkt."""
    pool = [
        pair
        for pair in ranked
        if not places_only or pair[0].kind == "place"
    ]
    if pin_keys:
        pinned = [pair for pair in pool if pair[0].key in pin_keys]
        rest = [pair for pair in pool if pair[0].key not in pin_keys]
        pool = pinned + rest
    target = stop_count if stop_count is not None else limit
    if min_stops is not None:
        target = max(target, min_stops)
    target = min(target, limit)

    def visit_minutes(item: ScoreInput) -> int:
        if item.kind == "place":
            return _place_visit_minutes(place_by_key[item.key])
        return _event_visit_minutes(event_by_key[item.key])

    def slice_count(pool_size: int) -> int:
        count = min(target, pool_size)
        if min_stops is not None and pool_size >= min_stops:
            count = max(count, min(min_stops, pool_size))
        return count

    if budget_minutes is None:
        return pool[: slice_count(len(pool))]

    picked: list[tuple[ScoreInput, float]] = []
    total = 0
    for item, score in pool:
        duration = visit_minutes(item)
        if duration > budget_minutes:
            continue
        if total + duration > budget_minutes:
            continue
        picked.append((item, score))
        total += duration
        if len(picked) >= target:
            break
    if (
        min_stops is not None
        and len(picked) < min_stops
        and len(pool) >= min_stops
    ):
        picked_keys = {pair[0].key for pair in picked}
        for item, score in pool:
            if item.key in picked_keys:
                continue
            duration = visit_minutes(item)
            if duration > budget_minutes:
                continue
            if total + duration > budget_minutes:
                continue
            picked.append((item, score))
            picked_keys.add(item.key)
            total += duration
            if len(picked) >= min_stops:
                break
    return picked


async def _candidate_places(filt: SearchFilter) -> list[Place]:
    qs = Place.all()
    if filt.city:
        qs = qs.filter(city__iexact=filt.city)
    if _kids(filt):
        qs = qs.filter(adult_only=False)
    if filt.setting_strict and filt.setting is SettingPreference.OUTDOOR:
        qs = qs.filter(is_outdoor=True)
    elif filt.setting_strict and filt.setting is SettingPreference.INDOOR:
        qs = qs.filter(is_indoor=True)
    if filt.price_strict and filt.max_price_level is not None:
        qs = qs.filter(
            Q(price_level__isnull=True) | Q(price_level__lte=filt.max_price_level)
        )
    return await qs


async def _open_place_ids(day_of_week: int) -> tuple[set[int], set[int]]:
    rows = await OpeningHours.all().values_list("place_id", "day_of_week")
    any_hours: set[int] = set()
    open_today: set[int] = set()
    for place_id, weekday in rows:
        any_hours.add(place_id)
        if weekday == day_of_week:
            open_today.add(place_id)
    return any_hours, open_today


def _event_blocked(event: Event, filt: SearchFilter) -> bool:
    if filt.time_budget_minutes is not None:
        if _event_visit_minutes(event) > filt.time_budget_minutes:
            return True
    if filt.price_strict and filt.max_price_level is not None and not event.is_free:
        price = _price_int(event.price_level)
        if price is not None and price > filt.max_price_level:
            return True
    if _kids(filt) and event.age_group:
        age_group = event.age_group.lower()
        if any(token in age_group for token in ("18", "senior", "doros")):
            return True
    return False


async def _candidate_events(filt: SearchFilter) -> list[Event]:
    if filt.date is None:
        return []
    qs = Event.filter(start_date=filt.date)
    if filt.city:
        qs = qs.filter(Q(city__iexact=filt.city) | Q(city__isnull=True))
    events = await qs
    return [event for event in events if not _event_blocked(event, filt)]


def _event_category(event: Event) -> str | None:
    if event.category:
        return event.category
    if event.sport:
        return "kibicowanie_wydarzenia_sportowe"
    return None


def _event_price(event: Event) -> int | None:
    if event.is_free:
        return 0
    return _price_int(event.price_level)


def _place_flags(
    place: Place,
    *,
    any_hours: set[int],
    check_day: bool,
) -> list[SearchResultFlag]:
    flags: list[SearchResultFlag] = []
    if place.price_level is None:
        flags.append(SearchResultFlag.PRICE_UNCONFIRMED)
    if check_day and place.id not in any_hours:
        flags.append(SearchResultFlag.CHECK_HOURS)
    return flags


def _event_flags(event: Event) -> list[SearchResultFlag]:
    if event.is_free or event.price_level is not None:
        return []
    return [SearchResultFlag.PRICE_UNCONFIRMED]


async def _weather_bias(target: date | None, lat: float, lon: float) -> WeatherBias:
    service = get_weather_service()
    forecast: WeatherForecast | None = None
    try:
        forecast = await service.get_forecast(lat, lon, hours=72)
    except (WeatherProviderError, httpx.HTTPError, OSError):
        forecast = None
    if forecast is not None and target is not None:
        daytime = [
            hour
            for hour in forecast.hours
            if hour.start.astimezone(_WARSAW).date() == target
            and 8 <= hour.start.astimezone(_WARSAW).hour <= 19
        ]
        if daytime:
            bad = sum(
                1
                for hour in daytime
                if hour.condition in _BAD_WEATHER or not hour.is_outdoor_friendly
            )
            return WeatherBias(
                raining=bad * 2 >= len(daytime),
                condition=daytime[0].condition.value,
                used=True,
            )
    try:
        snapshot = await service.get_current(lat, lon)
    except (WeatherProviderError, httpx.HTTPError, OSError):
        return WeatherBias(raining=False, used=False)
    raining = (not snapshot.is_outdoor_friendly) or snapshot.condition in _BAD_WEATHER
    return WeatherBias(raining=raining, condition=snapshot.condition.value, used=True)


def _reasons_prompt() -> str:
    return _REASONS_PROMPT.read_text(encoding="utf-8").strip()


async def explain_results(
    results: list[SearchResult],
    *,
    query: str,
    filt: SearchFilter,
    client: LLMClient,
) -> None:
    if not results:
        return
    payload = [
        {
            "kind": item.kind,
            "id": item.id,
            "name": item.name,
            "category": item.category,
            "city": item.city,
            "flags": [flag.value for flag in item.flags],
        }
        for item in results[:15]
    ]
    user = json.dumps(
        {"query": query, "filter": filt.model_dump(mode="json"), "results": payload},
        ensure_ascii=False,
    )
    raw = await client.chat_completion(
        [
            {"role": "system", "content": _reasons_prompt()},
            {"role": "user", "content": user},
        ],
        json_schema=SEARCH_REASONS_JSON_SCHEMA,
        schema_name="search_reasons",
    )
    data = extract_json_object(raw)
    rows = data.get("items")
    if not isinstance(rows, list):
        raise ValueError("missing items")
    by_key = {(item.kind, item.id): item for item in results}
    for row in rows:
        if not isinstance(row, dict):
            continue
        target = by_key.get((row.get("kind"), row.get("id")))
        reason = row.get("reason")
        if target is None or not isinstance(reason, str):
            continue
        text = " ".join(reason.split())
        if text:
            target.reason = text[:160]


async def _maybe_explain(
    results: list[SearchResult],
    *,
    query: str,
    filt: SearchFilter,
    settings: Settings,
) -> None:
    if not settings.search_llm_reasons or not settings.resolved_llm_api_key:
        return
    try:
        await explain_results(
            results,
            query=query,
            filt=filt,
            client=LLMClient(settings),
        )
    except (LLMUnavailableError, ValueError, json.JSONDecodeError, OSError):
        return


async def search_catalog(
    request: SearchRequest,
    *,
    today: date | None = None,
    settings: Settings | None = None,
) -> SearchResponse:
    resolved_settings = settings or get_settings()
    resolved_today = today or warsaw_today()
    llm_query = request.query + preferences_query_suffix(request.user_preferences)
    parsed: ParsedQuery = await parse_search_query(
        llm_query,
        today=resolved_today,
        settings=resolved_settings,
    )
    query_time_budget = parsed.filter.time_budget_minutes
    query_stop_count = parsed.filter.stop_count
    interest_layers = resolve_interest_layers(
        request.query,
        parsed.filter.interests,
        request.user_preferences,
    )
    filt = merge_user_preferences(parsed.filter, request.user_preferences)
    if query_time_budget is None:
        filt = filt.model_copy(update={"time_budget_minutes": None})
    primary_interests = list(interest_layers.query) or list(interest_layers.preference)
    if primary_interests != list(filt.interests):
        filt = filt.model_copy(update={"interests": primary_interests})
    places = await _candidate_places(filt)
    any_hours: set[int] = set()
    open_today: set[int] = set()
    if filt.day_of_week is not None:
        any_hours, open_today = await _open_place_ids(filt.day_of_week)
        places = [
            place
            for place in places
            if place.id not in any_hours or place.id in open_today
        ]
    events = await _candidate_events(filt)
    events = filter_events_for_query(events, request.query)
    mention_scores = mention_scores_for_catalog(request.query, places, events)
    pin_keys = strong_mention_keys(mention_scores)
    venue_focus = bool(pin_keys)
    if venue_focus:
        filt = filt.model_copy(update={"setting": SettingPreference.EITHER})
    profile = (
        request.user_preferences.profile
        if request.user_preferences is not None and not venue_focus
        else None
    )

    scored_inputs: list[ScoreInput] = []
    place_by_key: dict[str, Place] = {}
    event_by_key: dict[str, Event] = {}
    for place in places:
        key = f"place:{place.id}"
        place_by_key[key] = place
        scored_inputs.append(
            ScoreInput(
                key=key,
                category=place.category,
                secondary_categories=_split_secondary(place.secondary_categories),
                family_friendly=place.family_friendly or 0,
                rain_suitable=place.rain_suitable or 0,
                physical_activity_level=place.physical_activity_level or 0,
                is_indoor=bool(place.is_indoor),
                is_outdoor=bool(place.is_outdoor),
                min_age_recommended=place.min_age_recommended,
                price_level=_price_int(place.price_level),
                game_interactivity=place.game_interactivity or 0,
                gastro_intensity=place.gastro_intensity or 0,
                cultural_education=place.cultural_education or 0,
                nature_relaxation=place.nature_relaxation or 0,
                kind="place",
            )
        )
    for event in events:
        key = f"event:{event.id}"
        event_by_key[key] = event
        category = _event_category(event)
        activity = 4 if category == "sport_aktywny_wypoczynek" else 1 if event.sport else 0
        scored_inputs.append(
            ScoreInput(
                key=key,
                category=category,
                family_friendly=2,
                rain_suitable=2,
                physical_activity_level=activity,
                price_level=_event_price(event),
                kind="event",
            )
        )

    lat = request.lat if request.lat is not None else _PLOCK_LAT
    lon = request.lon if request.lon is not None else _PLOCK_LON
    bias = await _weather_bias(filt.date, lat, lon)
    event_intent = query_event_intent(request.query, filt)
    min_pack_stops: int | None = None
    if (
        query_stop_count is None
        and query_time_budget is None
        and not event_intent
    ):
        min_pack_stops = _MIN_STOPS_WITHOUT_EXPLICIT_PLAN
    if pin_keys:
        min_pack_stops = None
    ranked = rank_matches(
        scored_inputs,
        filt,
        bias,
        event_intent=event_intent,
        profile=profile,
        interest_layers=interest_layers,
    )
    ranked = _apply_query_relevance(
        ranked,
        query=request.query,
        mention_scores=mention_scores,
        place_by_key=place_by_key,
        event_by_key=event_by_key,
        event_intent=event_intent,
    )
    if venue_focus:
        ranked = [pair for pair in ranked if pair[0].key in pin_keys]
    pack_limit = request.limit
    if venue_focus:
        pack_limit = min(pack_limit, _VENUE_FOCUS_RESULT_CAP, len(ranked) or 1)
    if query_stop_count is not None and not venue_focus:
        pack_limit = max(request.limit, query_stop_count)
    ranked = _pack_ranked_within_budget(
        ranked,
        place_by_key=place_by_key,
        event_by_key=event_by_key,
        budget_minutes=query_time_budget,
        limit=pack_limit,
        stop_count=query_stop_count,
        places_only=query_stop_count is not None and not event_intent,
        min_stops=min_pack_stops,
        pin_keys=pin_keys or None,
    )

    results: list[SearchResult] = []
    for item, score in ranked:
        if item.kind == "place":
            place = place_by_key[item.key]
            results.append(
                SearchResult(
                    kind="place",
                    id=place.id,
                    external_id=place.external_id,
                    name=place.name,
                    category=place.category,
                    city=place.city,
                    score=round(score, 2),
                    flags=_place_flags(
                        place,
                        any_hours=any_hours,
                        check_day=filt.day_of_week is not None,
                    ),
                    price_level=_price_int(place.price_level),
                    is_indoor=bool(place.is_indoor),
                    is_outdoor=bool(place.is_outdoor),
                    typical_visit_minutes=place.typical_visit_minutes,
                    address_line=place.address_line,
                    latitude=place.latitude,
                    longitude=place.longitude,
                )
            )
            continue
        event = event_by_key[item.key]
        results.append(
            SearchResult(
                kind="event",
                id=event.id,
                external_id=event.external_id,
                name=event.name,
                category=_event_category(event),
                city=event.city,
                score=round(score, 2),
                flags=_event_flags(event),
                price_level=_event_price(event),
                typical_visit_minutes=_minutes_between(event.start_time, event.end_time),
                address_line=event.address_line,
                latitude=event.latitude,
                longitude=event.longitude,
                start_date=event.start_date,
                start_time=event.start_time,
            )
        )

    await _maybe_explain(
        results,
        query=request.query,
        filt=filt,
        settings=resolved_settings,
    )
    return SearchResponse(
        query=request.query,
        summary=summarize_search_response(
            request.query,
            filt,
            results,
            venue_focus=venue_focus,
            today=resolved_today,
        ),
        filter=filt,
        parser=parsed.source,
        weather_used=bias.used,
        weather_raining=bias.raining,
        weather_note=_weather_note(bias, filt.setting),
        results=results,
    )
